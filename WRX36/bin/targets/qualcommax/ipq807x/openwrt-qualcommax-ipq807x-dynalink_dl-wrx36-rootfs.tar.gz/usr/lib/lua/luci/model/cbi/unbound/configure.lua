local m,e
local v,O,t,N
local S,w,R,g,_,z,E
local l,f,x,s,i,o,n
local j,I,p,b,T
local h,d,y,t,H
local a,c,u
local r,A,r
local r=require"luci.util"
local r=require"luci.sys"
local L=require"luci.http"
local D=require"luci.dispatcher"
local k=luci.model.uci.cursor()
local q=k:get_first("unbound","unbound","manual_conf")
local U=k:get_first("unbound","unbound","dhcp_link")
local k=k:get_first("dhcp","odhcpd","leasetrigger")or"undefined"
m=Map("unbound")
e=m:section(TypedSection,"unbound",translate("Recursive DNS"),
translatef("Unbound <a href=\"%s\" target=\"_blank\">(NLnet Labs)</a>"
.." is a validating, recursive, and caching DNS resolver"
.." <a href=\"%s\" target=\"_blank\">(help)</a>.",
"https://www.unbound.net/",
"https://github.com/openwrt/packages/blob/master/net/unbound/files/README.md"))
e.addremove=false
e.anonymous=true
if(q=="0")and(U=="odhcpd")and(k~="/usr/lib/unbound/odhcpd.sh")then
m.message=translatef("Note: local DNS is configured to look at odhpcd, "
.."but odhpcd UCI lease trigger is incorrectly set: ")
.."dhcp.odhcpd.leasetrigger='"..k.."'"
end
e:tab("basic",translate("Basic"))
if(q=="0")then
e:tab("advanced",translate("Advanced"))
e:tab("DHCP",translate("DHCP"))
e:tab("resource",translate("Resource"))
end
v=e:taboption("basic",Flag,"enabled",translate("Enable Unbound"),
translate("Enable the initialization scripts for Unbound"))
v.rmempty=false
O=e:taboption("basic",Flag,"manual_conf",translate("Manual Conf"),
translate("Skip UCI and use /etc/unbound/unbound.conf"))
O.rmempty=false
if(q=="0")then
N=e:taboption("basic",Flag,"localservice",
translate("Local Service"),
translate("Accept queries only from local subnets"))
N.rmempty=false
R=e:taboption("basic",Flag,"validator",
translate("Enable DNSSEC"),
translate("Enable the DNSSEC validator module"))
R.rmempty=false
g=e:taboption("basic",Flag,"validator_ntp",
translate("DNSSEC NTP Fix"),
translate("Break the loop where DNSSEC needs NTP and NTP needs DNS"))
g.optional=true
g.default=true
g:depends("validator",true)
z=e:taboption("basic",Value,"listen_port",
translate("Listening Port"),
translate("Choose Unbounds listening port"))
z.datatype="port"
z.placeholder="53"
S=e:taboption("advanced",Flag,"rebind_localhost",
translate("Filter Localhost Rebind"),
translate("Protect against upstream response of 127.0.0.0/8"))
S.rmempty=false
w=e:taboption("advanced",ListValue,"rebind_protection",
translate("Filter Private Rebind"),
translate("Protect against upstream responses within local subnets"))
w:value("0",translate("No Filter"))
w:value("1",translate("Filter Private Address"))
w:value("2",translate("Filter Entire Subnet"))
w.rmempty=false
I=e:taboption("advanced",Flag,"dns64",translate("Enable DNS64"),
translate("Enable the DNS64 module"))
I.rmempty=false
p=e:taboption("advanced",Value,"dns64_prefix",
translate("DNS64 Prefix"),
translate("Prefix for generated DNS64 addresses"))
p.datatype="ip6addr"
p.placeholder="64:ff9b::/96"
p.optional=true
p:depends("dns64",true)
A=e:taboption("advanced",DynamicList,"domain_insecure",
translate("Domain Insecure"),
translate("List domains to bypass checks of DNSSEC"))
A:depends("validator",true)
t=e:taboption("advanced",Value,"root_age",
translate("Root DSKEY Age"),
translate("Limit days between RFC5011 copies to reduce flash writes"))
t.datatype="and(uinteger,min(1),max(99))"
t:value("3","3")
t:value("9","9 ("..translate("default")..")")
t:value("12","12")
t:value("24","24")
t:value("99","99 ("..translate("never")..")")
c=e:taboption("advanced",Value,"iface_lan",
translate("LAN Networks"),
translate("Networks to consider LAN (served) beyond those served by DHCP"))
c.template="cbi/network_netlist"
c.widget="checkbox"
c.rmempty=true
c.cast="string"
c.nocreate=true
u=e:taboption("advanced",Value,"iface_wan",
translate("WAN Networks"),
translate("Networks to consider WAN (unserved)"))
u.template="cbi/network_netlist"
u.widget="checkbox"
u.rmempty=true
u.cast="string"
u.nocreate=true
a=e:taboption("advanced",Value,"iface_trig",
translate("Trigger Networks"),
translate("Networks that may trigger Unbound to reload (avoid wan6)"))
a.template="cbi/network_netlist"
a.widget="checkbox"
a.rmempty=true
a.cast="string"
a.nocreate=true
f=e:taboption("DHCP",ListValue,"dhcp_link",
translate("DHCP Link"),
translate("Link to supported programs to load DHCP into DNS"))
f:value("none",translate("(none)"))
f:value("dnsmasq","dnsmasq")
f:value("odhcpd","odhcpd")
f.rmempty=false
j=e:taboption("DHCP",Flag,"dhcp4_slaac6",
translate("DHCPv4 to SLAAC"),
translate("Use DHCPv4 MAC to discover IP6 hosts SLAAC (EUI64)"))
j.optional=true
j:depends("dhcp_link","odhcpd")
x=e:taboption("DHCP",Value,"domain",
translate("Local Domain"),
translate("Domain suffix for this router and DHCP clients"))
x.placeholder="lan"
x.optional=true
s=e:taboption("DHCP",ListValue,"domain_type",
translate("Local Domain Type"),
translate("How to treat queries of this local domain"))
s.optional=true
s:value("deny",translate("Denied (nxdomain)"))
s:value("refuse",translate("Refused"))
s:value("static",translate("Static (local only)"))
s:value("transparent",translate("Transparent (local/global)"))
s:depends("dhcp_link","none")
s:depends("dhcp_link","odhcpd")
i=e:taboption("DHCP",ListValue,"add_local_fqdn",
translate("LAN DNS"),
translate("How to enter the LAN or local network router in DNS"))
i.optional=true
i:value("0",translate("No Entry"))
i:value("1",translate("Hostname, Primary Address"))
i:value("2",translate("Hostname, All Addresses"))
i:value("3",translate("Host FQDN, All Addresses"))
i:value("4",translate("Interface FQDN, All Addresses"))
i:depends("dhcp_link","none")
i:depends("dhcp_link","odhcpd")
o=e:taboption("DHCP",ListValue,"add_wan_fqdn",
translate("WAN DNS"),
translate("Override the WAN side router entry in DNS"))
o.optional=true
o:value("0",translate("Use Upstream"))
o:value("1",translate("Hostname, Primary Address"))
o:value("2",translate("Hostname, All Addresses"))
o:value("3",translate("Host FQDN, All Addresses"))
o:value("4",translate("Interface FQDN, All Addresses"))
o:depends("dhcp_link","none")
o:depends("dhcp_link","odhcpd")
n=e:taboption("DHCP",ListValue,"add_extra_dns",
translate("Extra DNS"),
translate("Use extra DNS entries found in /etc/config/dhcp"))
n.optional=true
n:value("0",translate("Ignore"))
n:value("1",translate("Host Records"))
n:value("2",translate("Host/MX/SRV RR"))
n:value("3",translate("Host/MX/SRV/CNAME RR"))
n:depends("dhcp_link","none")
n:depends("dhcp_link","odhcpd")
l=e:taboption("resource",ListValue,"unbound_control",
translate("Unbound Control App"),
translate("Enable access for unbound-control"))
l.rmempty=false
l:value("0",translate("No Remote Control"))
l:value("1",translate("Local Host, No Encryption"))
l:value("2",translate("Local Host, Encrypted"))
l:value("3",translate("Local Subnet, Encrypted"))
l:value("4",translate("Local Subnet, Static Encryption"))
h=e:taboption("resource",ListValue,"protocol",
translate("Recursion Protocol"),
translate("Choose the IP versions used upstream and downstream"))
h:value("default",translate("Default"))
h:value("ip4_only",translate("IP4 Only"))
h:value("ip6_local",translate("IP4 All and IP6 Local"))
h:value("ip6_only",translate("IP6 Only*"))
h:value("ip6_prefer",translate("IP6 Preferred"))
h:value("mixed",translate("IP4 and IP6"))
h.rmempty=false
d=e:taboption("resource",ListValue,"resource",
translate("Memory Resource"),
translate("Use menu System/Processes to observe any memory growth"))
d:value("default",translate("Default"))
d:value("tiny",translate("Tiny"))
d:value("small",translate("Small"))
d:value("medium",translate("Medium"))
d:value("large",translate("Large"))
d.rmempty=false
y=e:taboption("resource",ListValue,"recursion",
translate("Recursion Strength"),
translate("Recursion activity affects memory growth and CPU load"))
y:value("default",translate("Default"))
y:value("passive",translate("Passive"))
y:value("aggressive",translate("Aggressive"))
y.rmempty=false
b=e:taboption("resource",Flag,"query_minimize",
translate("Query Minimize"),
translate("Break down query components for limited added privacy"))
b.optional=true
b:depends("recursion","passive")
b:depends("recursion","aggressive")
T=e:taboption("resource",Flag,"query_min_strict",
translate("Strict Minimize"),
translate("Strict version of 'query minimize' but it can break DNS"))
T.optional=true
T:depends("query_minimize",true)
_=e:taboption("resource",Value,"edns_size",
translate("EDNS Size"),
translate("Limit extended DNS packet size"))
_.datatype="and(uinteger,min(512),max(4096))"
_.placeholder="1280"
E=e:taboption("resource",Value,"ttl_min",
translate("TTL Minimum"),
translate("Prevent excessively short cache periods"))
E.datatype="and(uinteger,min(0),max(1200))"
E.placeholder="120"
rtt=e:taboption("resource",Value,"rate_limit",
translate("Query Rate Limit"),
translate("Prevent client query overload; zero is off"))
rtt.datatype="and(uinteger,min(0),max(5000))"
rtt.placeholder="0"
H=e:taboption("resource",Flag,"extended_stats",
translate("Extended Statistics"),
translate("Extended statistics are printed from unbound-control"))
H.rmempty=false
else
t=e:taboption("basic",Value,"root_age",
translate("Root DSKEY Age"),
translate("Limit days between RFC5011 copies to reduce flash writes"))
t.datatype="and(uinteger,min(1),max(99))"
t:value("3","3")
t:value("9","9 ("..translate("default")..")")
t:value("12","12")
t:value("24","24")
t:value("99","99 ("..translate("never")..")")
a=e:taboption("basic",Value,"trigger_interface",
translate("Trigger Networks"),
translate("Networks that may trigger Unbound to reload (avoid wan6)"))
a.template="cbi/network_netlist"
a.widget="checkbox"
a.rmempty=true
a.cast="string"
a.nocreate=true
end
function v.cfgvalue(e,t)
return r.init.enabled("unbound")and e.enabled or e.disabled
end
function v.write(t,a,e)
if(e=="1")then
r.init.enable("unbound")
r.call("/etc/init.d/unbound start >/dev/null 2>&1")
else
r.call("/etc/init.d/unbound stop >/dev/null 2>&1")
r.init.disable("unbound")
end
return Flag.write(t,a,e)
end
function m.on_commit(e)
if r.init.enabled("unbound")then
r.call("/etc/init.d/unbound restart >/dev/null 2>&1")
else
r.call("/etc/init.d/unbound stop >/dev/null 2>&1")
end
end
function m.on_apply(e)
L.redirect(D.build_url("admin","services","unbound","configure"))
end
return m
