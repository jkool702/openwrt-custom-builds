module("luci.controller.unbound",package.seeall)
function index()
local e=require"nixio.fs"
local t=luci.model.uci.cursor()
local a=t:get_first("unbound","unbound","manual_conf")
if not e.access("/etc/config/unbound")then
return
end
local t=entry({"admin","services","unbound"},firstchild(),_("Recursive DNS"))
t.dependent=false
t.acl_depends={"luci-app-unbound"}
entry({"admin","services","unbound","configure"},
cbi("unbound/configure"),_("Unbound"),10)
if(a=="0")then
entry({"admin","services","unbound","zones"},
arcombine(cbi("unbound/zones"),cbi("unbound/zone-details")),
_("Zones"),15).leaf=true
end
entry({"admin","services","unbound","status"},
firstchild(),_("Status"),20)
entry({"admin","services","unbound","status","syslog"},
call("QuerySysLog"),_("Log"),50).leaf=true
if e.access("/usr/sbin/unbound-control")then
entry({"admin","services","unbound","status","statistics"},
call("QueryStatistics"),_("Statistics"),10).leaf=true
entry({"admin","services","unbound","status","localdata"},
call("QueryLocalData"),_("Local Data"),20).leaf=true
entry({"admin","services","unbound","status","localzone"},
call("QueryLocalZone"),_("Local Zones"),30).leaf=true
entry({"admin","services","unbound","status","dumpcache"},
call("QueryDumpCache"),_("DNS Cache"),40).leaf=true
else
entry({"admin","services","unbound","status","statistics"},
call("ShowEmpty"),_("Statistics"),10).leaf=true
end
entry({"admin","services","unbound","files"},
firstchild(),_("Files"),30)
if(a=="0")then
entry({"admin","services","unbound","files","uci"},
form("unbound/uciedit"),_("Edit: UCI"),5).leaf=true
entry({"admin","services","unbound","files","base"},
call("ShowUnboundConf"),_("Show: Unbound"),10).leaf=true
else
entry({"admin","services","unbound","files","base"},
form("unbound/manual"),_("Edit: Unbound"),10).leaf=true
end
entry({"admin","services","unbound","files","server"},
form("unbound/server"),_("Edit: Server"),20).leaf=true
entry({"admin","services","unbound","files","extended"},
form("unbound/extended"),_("Edit: Extended"),30).leaf=true
if e.access("/var/lib/unbound/dhcp.conf")then
entry({"admin","services","unbound","files","dhcp"},
call("ShowDHCPConf"),_("Show: DHCP"),40).leaf=true
end
if e.access("/var/lib/unbound/adb_list.overall")then
entry({"admin","services","unbound","files","adblock"},
call("ShowAdblock"),_("Show: Adblock"),50).leaf=true
end
end
function ShowEmpty()
local e="Unbound Control"
local t=luci.i18n.translate(
"This could display more statistics with the unbound-control package.")
luci.template.render("unbound/show-empty",
{heading=e,description=t})
end
function QuerySysLog()
local t=luci.util.exec("logread -e 'unbound'")
local e=luci.i18n.translate(
"This shows syslog filtered for events involving Unbound.")
luci.template.render("unbound/show-textbox",
{heading="",description=e,content=t})
end
function QueryStatistics()
local e=luci.util.exec(
"unbound-control -c /var/lib/unbound/unbound.conf stats_noreset")
local t=luci.i18n.translate(
"This shows Unbound self reported performance statistics.")
luci.template.render("unbound/show-textbox",
{heading="",description=t,content=e})
end
function QueryLocalData()
local t=luci.util.exec(
"unbound-control -c /var/lib/unbound/unbound.conf list_local_data")
local e=luci.i18n.translate(
"This shows Unbound 'local-data:' entries from default, .conf, or control.")
luci.template.render("unbound/show-textbox",
{heading="",description=e,content=t})
end
function QueryLocalZone()
local e=luci.util.exec(
"unbound-control -c /var/lib/unbound/unbound.conf list_local_zones")
local t=luci.i18n.translate(
"This shows Unbound 'local-zone:' entries from default, .conf, or control.")
luci.template.render("unbound/show-textbox",
{heading="",description=t,content=e})
end
function QueryDumpCache()
local o=require"luci.template"
local a=require"luci.i18n"
local e
local t=luci.util.exec(
"unbound-control -c /var/lib/unbound/unbound.conf dump_cache")
if#t>262144 then
e=a.translate(
"Unbound cache is too large to display in LuCI.")
o.render("unbound/show-empty",
{heading="",description=e})
else
e=a.translate(
"This shows 'ubound-control dump_cache' for auditing records including DNSSEC.")
o.render("unbound/show-textbox",
{heading="",description=e,content=t})
end
end
function ShowUnboundConf()
local e="/var/lib/unbound/unbound.conf"
local t=nixio.fs.readfile(e)
local e=luci.i18n.translate(
"This shows '"..e.."' generated from UCI configuration.")
luci.template.render("unbound/show-textbox",
{heading="",description=e,content=t})
end
function ShowDHCPConf()
local e="/var/lib/unbound/dhcp.conf"
local t=nixio.fs.readfile(e)
local e=luci.i18n.translate(
"This shows '"..e.."' list of hosts from DHCP hook scripts.")
luci.template.render("unbound/show-textbox",
{heading="",description=e,content=t})
end
function ShowAdblock()
local o=require"nixio.fs"
local a=require"luci.template"
local i=require"luci.i18n"
local t="/var/lib/unbound/adb_list.overall"
local n,e
if o.stat(t).size>262144 then
e=i.translate(
"Adblock domain list is too large to display in LuCI.")
a.render("unbound/show-empty",
{heading="",description=e})
else
n=o.readfile(t)
e=i.translate(
"This shows '"..t.."' list of adblock domains.")
a.render("unbound/show-textbox",
{heading="",description=e,content=n})
end
end
