local i,e
local a,o,s,l,r
local c=require"nixio.fs"
local n=require"luci.util"
local h=require"luci.sys"
local u=require"luci.dispatcher"
local d="/tmp/resolv.conf.auto"
local t=n.exec("logread -e 'unbound.*error.*ssl library'")
i=Map("unbound")
e=i:section(TypedSection,"zone","Zones",
translatef("Organize directed forward, stub, and authoritative zones"
.." <a href=\"%s\" target=\"_blank\">(help)</a>.",
"https://www.unbound.net/",
"https://github.com/openwrt/packages/blob/master/net/unbound/files/README.md"))
e.addremove=true
e.anonymous=true
e.sortable=true
e.template="cbi/tblsection"
e.extedit=u.build_url("admin/services/unbound/zones/%s")
a=e:option(DummyValue,"DummyType",translate("Type"))
a.rawhtml=true
o=e:option(DummyValue,"DummyZones",translate("Zones"))
o.rawhtml=true
s=e:option(DummyValue,"DummyServers",translate("Servers"))
s.rawhtml=true
l=e:option(Flag,"fallback",translate("Fallback"))
l.rmempty=false
r=e:option(Flag,"enabled",translate("Enable"))
r.rmempty=false
if t and(#t>0)then
t=t:sub((1+#t-math.min(#t,250)),#t)
i.message=translatef("Note: SSL/TLS library is missing an API. "
.."Please review syslog. >> logread ... "..t)
end
function e.create(e,t)
created=TypedSection.create(e,t)
end
function e.parse(e,...)
TypedSection.parse(e,...)
end
function a.cfgvalue(t,a)
local e=t.map:get(a,"zone_type")
local t=t.map:get(a,"tls_upstream")
if e and e:match("forward")then
if t and(t=="1")then
return translate("Forward TLS")
else
return translate("Forward")
end
elseif e and e:match("stub")then
return translate("Recurse")
elseif e and e:match("auth")then
return translate("AXFR")
else
return translate("Undefined")
end
end
function o.cfgvalue(t,a)
local o,e
local o=t.map:get(a,"zone_name")
local t=t.map:get(a,"zone_type")
for t in n.imatch(o)do
if(t==".")then
t=translate("(root)")
end
if e and(#e>0)then
e=e..", <var>%s</var>"%t
else
e="<var>%s</var>"%t
end
end
if e and(#e>0)then
if t and t:match("forward")then
e=translate("accept upstream results for ")..e
elseif t and t:match("stub")then
e=translate("select recursion for ")..e
elseif t and t:match("auth")then
e=translate("prefetch zone files for ")..e
else
e=translate("unknown action for ")..e
end
return e
else
return"(empty)"
end
end
function s.cfgvalue(a,o)
local i,e,t,h
local u=a.map:get(o,"server")
local i=a.map:get(o,"url_dir")
local s=a.map:get(o,"zone_type")
local l=a.map:get(o,"tls_upstream")
local r=a.map:get(o,"tls_index")
local a=a.map:get(o,"resolv_conf")
for t in n.imatch(u)do
if e and(#e>0)then
e=e..", <var>%s</var>"%t
else
e="<var>%s</var>"%t
end
end
if e and(#e>0)then
e=translate("use nameservers ")..e
end
if e and(#e>0)
and l and(l=="1")
and r and(#r>0)then
e=e..translatef(
" with default certificate for <var>%s</var>",r)
end
if i and(#i>0)and s and s:match("auth")then
if e and(#e>0)then
e=e..translatef(", and try <var>%s</var>",i)
else
e=translatef("download from <var>%s</var>",i)
end
end
if a and(a=="1")and s and s:match("forward")then
for e in n.imatch(c.readfile(d))do
if e:match("nameserver")then
h=true
elseif(h==true)then
if t and(#t>0)then
t=t..", <var>%s</var>"%e
else
t="<var>%s</var>"%e
end
h=false
end
end
if e and(#e>0)and t and(#t>0)then
e=e..translatef(
", and <var>%s</var> entries ",d)..t
elseif t and(#t>0)then
e=translatef(
"use <var>%s</var> nameservers ",d)..t
end
end
if e and(#e>0)then
return e
else
return"(empty)"
end
end
function i.on_commit(e)
if h.init.enabled("unbound")then
h.call("/etc/init.d/unbound restart >/dev/null 2>&1")
else
h.call("/etc/init.d/unbound stop >/dev/null 2>&1")
end
end
return i
