local e,i,t
local a="/etc/config/unbound"
local o=require"nixio.fs"
local n=require"luci.util"
e=SimpleForm("editing",nil)
e:append(Template("unbound/css-editing"))
e.submit=translate("Save")
e.reset=false
i=e:section(SimpleSection,"",
translatef("Edit '"..a.."' "
.."and recipes can be found in OpenWrt "
.."<a href=\"%s\" target=\"_blank\">Guides</a> "
.."and <a href=\"%s\" target=\"_blank\">Github</a>.",
"https://openwrt.org/docs/guide-user/services/dns/unbound",
"https://github.com/openwrt/packages/blob/master/net/unbound/files/README.md"))
t=i:option(TextValue,"data")
t.datatype="string"
t.rows=20
function t.cfgvalue()
return o.readfile(a)or""
end
function t.write(t,t,e)
return o.writefile(a,n.trim(e:gsub("\r\n","\n")))
end
return e
