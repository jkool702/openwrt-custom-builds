module("luci.controller.rpc",package.seeall)
function session_retrieve(t,o)
local a=require"luci.util"
local e=a.ubus("session","get",{
ubus_rpc_session=t
})
if type(e)=="table"and
type(e.values)=="table"and
type(e.values.token)=="string"and
type(e.values.username)=="string"and
a.contains(o,e.values.username)
then
return t,e.values
end
return nil
end
function authenticator(e,o)
local e=require"luci.http"
local a=require"luci.controller.rpc"
local t=e.formvalue("auth",true)or e.getcookie("sysauth")
if t then
local a,t=a.session_retrieve(t,o)
if t then
return t.username,a
end
e.status(403,"Forbidden")
end
end
function index()
local t=require"luci.controller.rpc"
local e=node("rpc")
e.sysauth="root"
e.sysauth_authenticator=t.authenticator
e.notemplate=true
entry({"rpc","uci"},call("rpc_uci"))
entry({"rpc","fs"},call("rpc_fs"))
entry({"rpc","sys"},call("rpc_sys"))
entry({"rpc","ipkg"},call("rpc_ipkg"))
entry({"rpc","ip"},call("rpc_ip"))
entry({"rpc","auth"},call("rpc_auth")).sysauth=false
end
function rpc_auth()
local i=require"luci.controller.rpc"
local n=require"luci.jsonrpc"
local e=require"luci.http"
local s=require"luci.sys"
local h=require"luci.ltn12"
local a=require"luci.util"
local t={}
t.challenge=function(o,e)
local n=require"luci.config"
local e=a.ubus("session","login",{
username=o,
password=e,
timeout=tonumber(n.sauth.sessiontime)
})
if type(e)=="table"and
type(e.ubus_rpc_session)=="string"
then
a.ubus("session","set",{
ubus_rpc_session=e.ubus_rpc_session,
values={
token=s.uniqueid(16)
}
})
local t,e=i.session_retrieve(e.ubus_rpc_session,{o})
if e then
return{
sid=t,
token=e.token
}
end
end
return nil
end
t.login=function(...)
local t=t.challenge(...)
if t then
e.header("Set-Cookie",'sysauth=%s; path=%s'%{
t.sid,
e.getenv("SCRIPT_NAME")
})
return t.sid
end
end
e.prepare_content("application/json")
h.pump.all(n.handle(t,e.source()),e.write)
end
function rpc_uci()
if not pcall(require,"luci.model.uci")then
luci.http.status(404,"Not Found")
return nil
end
local t=require"luci.jsonrpcbind.uci"
local a=require"luci.jsonrpc"
local e=require"luci.http"
local o=require"luci.ltn12"
e.prepare_content("application/json")
o.pump.all(a.handle(t,e.source()),e.write)
end
function rpc_fs()
local e=require"luci.util"
local o=require"io"
local a=e.clone(require"nixio.fs")
local n=require"luci.jsonrpc"
local t=require"luci.http"
local e=require"luci.ltn12"
function a.readfile(a)
local t,i=pcall(require,"mime")
if not t then
error("Base64 support not available. Please install LuaSocket.")
end
local t=o.open(a)
if not t then
return nil
end
local a={}
local o=e.sink.table(a)
local t=e.source.chain(e.source.file(t),i.encode("base64"))
return e.pump.all(t,o)and table.concat(a)
end
function a.writefile(a,n)
local i,s=pcall(require,"mime")
if not i then
error("Base64 support not available. Please install LuaSocket.")
end
local a=o.open(a,"w")
local a=a and e.sink.chain(s.decode("base64"),e.sink.file(a))
return a and e.pump.all(e.source.string(n),a)or false
end
t.prepare_content("application/json")
e.pump.all(n.handle(a,t.source()),t.write)
end
function rpc_sys()
local t=require"luci.util"
local e=require"luci.sys"
local n=require"luci.jsonrpc"
local o=require"luci.http"
local i=require"luci.ltn12"
local a=t.clone(e)
a.net=t.clone(e.net)
a.wifi=t.clone(e.wifi)
function a.wifi.getiwinfo(a,t)
local e=e.wifi.getiwinfo(a)
if e then
if t then
assert(type(iwinfo[e.type][t])=="function")
return e[t]
end
local t,t
local a={ifname=a}
for t,o in pairs(iwinfo[e.type])do
if type(o)=="function"and
t~="scanlist"and t~="countrylist"
then
a[t]=e[t]
end
end
return a
end
return nil
end
o.prepare_content("application/json")
i.pump.all(n.handle(a,o.source()),o.write)
end
function rpc_ipkg()
if not pcall(require,"luci.model.ipkg")then
luci.http.status(404,"Not Found")
return nil
end
local a=require"luci.model.ipkg"
local t=require"luci.jsonrpc"
local e=require"luci.http"
local o=require"luci.ltn12"
e.prepare_content("application/json")
o.pump.all(t.handle(a,e.source()),e.write)
end
function rpc_ip()
if not pcall(require,"luci.ip")then
luci.http.status(404,"Not Found")
return nil
end
local e=require"luci.util"
local o=require"luci.ip"
local h=require"luci.jsonrpc"
local t=require"luci.http"
local s=require"luci.ltn12"
local a=e.clone(o)
local e,e
for i,e in ipairs({"new","IPv4","IPv6","MAC"})do
a[e]=function(n,a,t,i)
local e=o[e](n,a)
if e and t then
assert(type(e[t])=="function")
local e=e[t](e,i)
return(type(e)=="userdata")and e:string()or e
end
return(type(e)=="userdata")and e:string()or e
end
end
t.prepare_content("application/json")
s.pump.all(h.handle(a,t.source()),t.write)
end
