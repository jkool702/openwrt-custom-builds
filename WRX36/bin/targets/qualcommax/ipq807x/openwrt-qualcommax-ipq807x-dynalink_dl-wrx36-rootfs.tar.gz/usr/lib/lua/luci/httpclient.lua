require"nixio.util"
local r=require"nixio"
local n=require"luci.ltn12"
local e=require"luci.util"
local s=require"table"
local f=require"luci.http"
local m=require"luci.http.date"
local h=require"luci.ip"
local i,c,d,u,y=type,pairs,ipairs,tonumber,tostring
local w,l=unpack,string
module"luci.httpclient"
function chunksource(i,t)
t=t or""
return function()
local o
local n,a,e=t:find("^([0-9a-fA-F]+);?.-\r\n")
while not e and#t<=1024 do
local o,i=i:recv(1024-#t)
if not o then
return nil,i
end
t=t..o
n,a,e=t:find("^([0-9a-fA-F]+);?.-\r\n")
end
e=u(e,16)
if not e then
return nil,-1,"invalid encoding"
elseif e==0 then
return nil
elseif e+2<=#t-a then
o=t:sub(a+1,a+e)
t=t:sub(a+e+3)
return o
else
o=t:sub(a+1,a+e)
t=""
if e-#o>0 then
local a,t=i:recvall(e-#o)
if not a then
return nil,t
end
o=o..a
e,t=i:recvall(2)
else
e,code=i:recvall(e+2-#t+a)
end
if not e then
return nil,code
end
return o
end
end
end
function request_to_buffer(t,e)
local e,t,o=request_to_source(t,e)
local a={}
if not e then
return nil,t,o
end
e,t=n.pump.all(e,(n.sink.table(a)))
if not e then
return nil,t
end
return s.concat(a)
end
function request_to_source(t,e)
local e,a,t,o=request_raw(t,e)
if not e then
return e,a,t
elseif e~=200 and e~=206 then
return nil,e,t
end
if a.headers["Transfer-Encoding"]=="chunked"then
return chunksource(o,t)
else
return n.source.cat(n.source.string(t),o:blocksource())
end
end
function parse_url(o)
local e,a,t={},nil,nil
e.scheme,a=o:match("^(%w+)://(.+)$")
if not(e.scheme and a)then
return nil
end
e.auth,t=a:match("^([^@]+)@(.+)$")
if e.auth and t then
a=t
end
e.host,t=a:match("^%[(.+)%](.*)$")
if e.host and t then
e.ip6addr=h.IPv6(e.host)
if not e.ip6addr or e.ip6addr:prefix()<128 then
return nil
end
e.host=l.format("[%s]",e.ip6addr:string())
a=t
else
e.host,t=a:match("^(%d+%.%d+%.%d+%.%d+)(.*)$")
if e.host and t then
e.ipaddr=h.IPv4(e.host)
if not e.ipaddr then
return nil
end
e.host=e.ipaddr:string()
a=t
else
e.host,t=a:match("^([0-9a-zA-Z%.%-]+)(.*)$")
if e.host and t then
a=t
else
return nil
end
end
end
e.port,t=a:match("^:(%d+)(.*)$")
if e.port and t then
e.port=u(e.port)
a=t
if e.port<1 or e.port>65535 then
return nil
end
end
if e.scheme=="http"then
e.port=e.port or 80
e.default_port=(e.port==80)
elseif e.scheme=="https"then
e.port=e.port or 443
e.default_port=(e.port==443)
end
if a==""then
e.path="/"
else
e.path=a
end
return e
end
function request_raw(h,e)
e=e or{}
if e.params then
h=h..'?'..f.urlencode_params(e.params)
end
local t=parse_url(h)
if not t then
return nil,-1,"unable to parse URI"
end
if t.scheme~="http"and t.scheme~="https"then
return nil,-2,"protocol not supported"
end
e.depth=e.depth or 10
local a=e.headers or{}
local n=e.protocol or"HTTP/1.1"
a["User-Agent"]=a["User-Agent"]or"LuCI httpclient 0.1"
if a.Connection==nil then
a.Connection="close"
end
if t.auth and not a.Authorization then
a.Authorization="Basic "..r.bin.b64encode(t.auth)
end
local o=y(t.ip6addr or t.ipaddr or t.host)
local o,m,y=r.connect(o,t.port)
if not o then
return nil,m,y
end
o:setsockopt("socket","sndtimeo",e.sndtimeo or 15)
o:setsockopt("socket","rcvtimeo",e.rcvtimeo or 15)
if t.scheme=="https"then
local e=e.tls_context or r.tls()
o=e:create(o)
local e,a,t=o:connect()
if not e then
return e,a,t
end
end
if n=="HTTP/1.1"then
a.Host=a.Host or
(t.default_port and t.host or l.format("%s:%d",t.host,t.port))
end
if i(e.body)=="table"then
e.body=f.urlencode_params(e.body)
end
if i(e.body)=="string"then
a["Content-Length"]=a["Content-Length"]or#e.body
a["Content-Type"]=a["Content-Type"]or
"application/x-www-form-urlencoded"
e.method=e.method or"POST"
end
if i(e.body)=="function"then
e.method=e.method or"POST"
end
if e.cookies then
local o={}
for a,e in d(e.cookies)do
local i=e.flags.domain
local a=e.flags.path
if(i==t.host or i=="."..t.host or t.host:sub(-#i)==i)
and(a==t.path or a=="/"or a.."/"==t.path:sub(#a+1))
and(not e.flags.secure or t.scheme=="https")
then
o[#o+1]=e.key.."="..e.value
end
end
if a["Cookie"]then
a["Cookie"]=a["Cookie"].."; "..s.concat(o,"; ")
else
a["Cookie"]=s.concat(o,"; ")
end
end
local n={(e.method or"GET").." "..t.path.." "..n}
for t,e in c(a)do
if i(e)=="string"or i(e)=="number"then
n[#n+1]=t..": "..e
elseif i(e)=="table"then
for a,e in d(e)do
n[#n+1]=t..": "..e
end
end
end
n[#n+1]=""
n[#n+1]=""
o:sendall(s.concat(n,"\r\n"))
if i(e.body)=="string"then
o:sendall(e.body)
elseif i(e.body)=="function"then
local e={e.body(o)}
if not e[1]then
o:close()
return w(e)
end
end
local r=o:linesource()
local n,c,a=r()
if not n then
o:close()
return nil,c,a
end
local a,c,m=n:match("^([%w./]+) ([0-9]+) (.*)")
if not a then
o:close()
return nil,-3,"invalid response magic: "..n
end
local a={
status=n,headers={},code=0,cookies={},uri=h
}
n=r()
while n and n~=""do
local e,t=n:match("^([%w-]+)%s?:%s?(.*)")
if e and e~="Status"then
if i(a.headers[e])=="string"then
a.headers[e]={a.headers[e],t}
elseif i(a.headers[e])=="table"then
a.headers[e][#a.headers[e]+1]=t
else
a.headers[e]=t
end
end
n=r()
end
if not n then
o:close()
return nil,-4,"protocol error"
end
if a.headers["Set-Cookie"]then
local e=a.headers["Set-Cookie"]
for o,e in d(i(e)=="table"and e or{e})do
local e=cookie_parse(e)
e.flags.path=e.flags.path or t.path:match("(/.*)/?[^/]*")
if not e.flags.domain or e.flags.domain==""then
e.flags.domain=t.host
a.cookies[#a.cookies+1]=e
else
local o,i={},{}
for e in t.host:gmatch("[^.]*")do
s.insert(o,1,e)
end
for e in e.flags.domain:gmatch("[^.]*")do
s.insert(i,1,e)
end
local n=true
for e,t in d(i)do
if o[e]~=t and#t~=0 then
n=false
break
elseif o[e]~=t and#t==0 then
if e~=#i or(#o~=e and#o+1~=e)then
n=false
break
end
end
end
if n and#i>1 and#i[2]>0 then
a.cookies[#a.cookies+1]=e
end
end
end
end
a.code=u(c)
if a.code and e.depth>0 then
if(a.code==301 or a.code==302 or a.code==307)
and a.headers.Location then
local a=a.headers.Location or a.headers.location
if not a then
return nil,-5,"invalid reference"
end
if not a:match("^%w+://")then
a=t.default_port and l.format("%s://%s%s",t.scheme,t.host,a)
or l.format("%s://%s:%d%s",t.scheme,t.host,t.port,a)
end
e.depth=e.depth-1
if e.headers then
e.headers.Host=nil
end
o:close()
return request_raw(a,e)
end
end
return a.code,a,r(true)..o:readall(),o
end
function cookie_parse(e)
local e,a,t=e:match("%s?([^=;]+)=?([^;]*)(.*)")
if not e then
return nil
end
local a={key=e,value=a,flags={}}
for e,t in t:gmatch(";%s?([^=;]+)=?([^;]*)")do
e=e:lower()
if e=="expires"then
t=m.to_unix(t:gsub("%-"," "))
end
a.flags[e]=t
end
return a
end
function cookie_create(e)
local t={e.key.."="..e.value}
for a,e in c(e.flags)do
if a=="expires"then
e=m.to_http(e):gsub(", (%w+) (%w+) (%w+) ",", %1-%2-%3 ")
end
t[#t+1]=a..((#e>0)and("="..e)or"")
end
return s.concat(t,"; ")
end
