module("luci.jsonrpc",package.seeall)
require"luci.json"
function resolve(e,t)
local t=luci.util.split(t,".")
for a=1,#t-1 do
if not type(e)=="table"then
break
end
e=rawget(e,t[a])
if not e then
break
end
end
e=type(e)=="table"and rawget(e,t[#t])or nil
if type(e)=="function"then
return e
end
end
function handle(a,t,...)
local e=luci.json.Decoder()
local o=luci.ltn12.pump.all(t,e:sink())
local e=e:get()
local t
local i=false
if o then
if type(e.method)=="string"
and(not e.params or type(e.params)=="table")then
local a=resolve(a,e.method)
if a then
t=reply(e.jsonrpc,e.id,
proxy(a,unpack(e.params or{})))
else
t=reply(e.jsonrpc,e.id,
nil,{code=-32601,message="Method not found."})
end
else
t=reply(e.jsonrpc,e.id,
nil,{code=-32600,message="Invalid request."})
end
else
t=reply("2.0",nil,
nil,{code=-32700,message="Parse error."})
end
return luci.json.Encoder(t,...):source()
end
function reply(e,a,t,o)
require"luci.json"
a=a or luci.json.null
if e~="2.0"then
e=nil
t=t or luci.json.null
o=o or luci.json.null
end
return{id=a,result=t,error=o,jsonrpc=e}
end
function proxy(e,...)
local e={luci.util.copcall(e,...)}
local t=table.remove(e,1)
if not t then
return nil,{code=-32602,message="Invalid params.",data=table.remove(e,1)}
else
if#e<=1 then
return e[1]or luci.json.null
else
return e
end
end
end
