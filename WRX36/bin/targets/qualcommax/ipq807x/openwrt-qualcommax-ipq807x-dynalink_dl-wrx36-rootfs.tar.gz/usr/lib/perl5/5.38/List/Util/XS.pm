package List::Util::XS;
use strict;
use warnings;
use List::Util;

our $VERSION = "1.63";       # FIXUP
$VERSION =~ tr/_//d;         # FIXUP

1;
__END__

