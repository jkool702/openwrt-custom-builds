use strict;
package Tie::Hash::NamedCapture;

our $VERSION = "0.13";

__END__

