local n=require"luci.sys"
local f=require"luci.dispatcher"
local w=require"luci.http"
local t,e
local m,u,a,l,c,d,r
local i,o,s,h
arg[1]=arg[1]or""
t=Map("unbound")
t.redirect=f.build_url("admin/services/unbound/zones")
if(arg[1]=="")then
w.redirect(t.redirect)
return
else
e=t:section(NamedSection,arg[1],"zone",
translatef("Directed Zone"),
translatef("Edit a forward, stub, or zone-file-cache zone "
.."for Unbound to use instead of recursion."))
e.anonymous=true
e.addremove=false
m=e:option(Flag,"enabled",translate("Enabled"),
translate("Enable this directed zone"))
m.rmempty=false
u=e:option(Flag,"fallback",translate("Fall Back"),
translate("Allow open recursion when record not in zone"))
u.rmempty=false
a=e:option(ListValue,"zone_type",translate("Zone Type"))
a:value("auth_zone",translate("Authoritative (zone file)"))
a:value("stub_zone",translate("Stub (forced recursion)"))
a:value("forward_zone",translate("Forward (simple handoff)"))
a.rmempty=false
l=e:option(DynamicList,"zone_name",translate("Zone Names"),
translate("Zone (Domain) names included in this zone combination"))
l.placeholder="new.example.net."
c=e:option(DynamicList,"server",translate("Servers"),
translate("Servers for this zone; see README.md for optional form"))
c.placeholder="192.0.2.53"
ast=e:option(ListValue,"dns_assist",translate("DNS Plugin"),
translate("Check for local program to allow forward to localhost"))
ast:value("none",translate("(none)"))
ast:value("bind","bind")
ast:value("dnsmasq","dnsmasq")
ast:value("ipset-dns","ipset-dns")
ast:value("nsd","nsd")
ast:value("unprotected-loop","unprotected-loop")
d=e:option(Flag,"resolv_conf",translate("Use 'resolv.conf.auto'"),
translate("Forward to upstream nameservers (ISP)"))
d:depends("zone_type","forward_zone")
r=e:option(Flag,"tls_upstream",translate("DNS over TLS"),
translate("Connect to servers using TLS"))
r:depends("zone_type","forward_zone")
i=e:option(Value,"port",translate("Server Port"),
translate("Port servers will receive queries on"))
i:depends("tls_upstream",false)
i.datatype="port"
i.placeholder="53"
o=e:option(Value,"tls_port",translate("Server TLS Port"),
translate("Port servers will receive queries on"))
o:depends("tls_upstream",true)
o.datatype="port"
o.placeholder="853"
s=e:option(Value,"tls_index",translate("TLS Name Index"),
translate("Domain name to verify TLS certificate"))
s:depends("tls_upstream",true)
s.placeholder="dns.example.net"
h=e:option(Value,"url_dir",translate("Zone Download URL"),
translate("Directory only part of URL"))
h:depends("zone_type","auth_zone")
h.placeholder="https://www.example.net/dl/zones/"
end
function t.on_commit(e)
if n.init.enabled("unbound")then
n.call("/etc/init.d/unbound restart >/dev/null 2>&1")
else
n.call("/etc/init.d/unbound stop >/dev/null 2>&1")
end
end
return t
