local e,i,t
local a="/etc/unbound/unbound_srv.conf"
local o=require"nixio.fs"
local n=require"luci.util"
e=SimpleForm("editing",nil)
e:append(Template("unbound/css-editing"))
e.submit=translate("Save")
e.reset=false
i=e:section(SimpleSection,"",
translatef(
"Edit 'server:' clause options for 'include: "..a.."'"))
t=i:option(TextValue,"data")
t.datatype="string"
t.rows=20
function t.cfgvalue()
return o.readfile(a)or""
end
function t.write(t,t,e)
return o.writefile(a,n.trim(e:gsub("\r\n","\n")))
end
return e
