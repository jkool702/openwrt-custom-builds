package Locale::Maketext::Guts;

use Locale::Maketext;

our $VERSION = '1.20';


1;
