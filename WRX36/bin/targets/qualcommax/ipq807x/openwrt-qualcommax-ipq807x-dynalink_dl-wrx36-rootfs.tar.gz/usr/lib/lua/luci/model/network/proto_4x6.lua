local t=luci.model.network
local e,e
for a,e in ipairs({"dslite","map","464xlat"})do
local a=t:register_protocol(e)
function a.get_i18n(t)
if e=="dslite"then
return luci.i18n.translate("Dual-Stack Lite (RFC6333)")
elseif e=="ipip6"then
return luci.i18n.translate("IPv4 over IPv6 (RFC2473-IPIPv6)")
elseif e=="map"then
return luci.i18n.translate("MAP / LW4over6")
elseif e=="464xlat"then
return luci.i18n.translate("464XLAT (CLAT)")
end
end
function a.ifname(t)
return e.."-"..t.sid
end
function a.opkg_package(t)
if e=="dslite"or e=="ipip6"then
return"ds-lite"
elseif e=="map"then
return"map-t"
elseif e=="464xlat"then
return"464xlat"
end
end
function a.is_installed(t)
return nixio.fs.access("/lib/netifd/proto/"..e..".sh")
end
function a.is_floating(e)
return true
end
function a.is_virtual(e)
return true
end
function a.get_interfaces(e)
return nil
end
function a.contains_interface(e,a)
return(t:ifnameof(a)==e:ifname())
end
end
t:register_pattern_virtual("^464%-%w")
t:register_pattern_virtual("^ds%-%w")
t:register_pattern_virtual("^ipip6%-%w")
t:register_pattern_virtual("^map%-%w")
t:register_error_code("AFTR_DNS_FAIL",luci.i18n.translate("Unable to resolve AFTR host name"))
t:register_error_code("INVALID_MAP_RULE",luci.i18n.translate("MAP rule is invalid"))
t:register_error_code("NO_MATCHING_PD",luci.i18n.translate("No matching prefix delegation"))
t:register_error_code("UNSUPPORTED_TYPE",luci.i18n.translate("Unsupported MAP type"))
