require"nixio.util"
local t=require"nixio"
local m=require"luci.httpclient"
local c=require"luci.ltn12"
local e,e,f,w=print,tonumber,require,unpack
module"luci.httpclient.receiver"
local function v(e)
local a=t.open_flags("wronly","creat")
local e,a,t=t.open(e,a)
if not e then
return e,a,t
end
local t,a,o=e:lock("tlock")
if not t then
return t,a,o
end
e:seek(0,"end")
return e
end
local function y(r,s,h,n,c)
local d=65536
local l=t.splice_flags("move","more","nonblock")
local e,a,o=h:setblocking(false)
if e then
e,a,o=s:setblocking(false)
end
if not e then
return e,a,o
end
local m={
{fd=r,events=t.poll_flags("in")}
}
local f={
{fd=n,events=t.poll_flags("out")}
}
local u
local i
repeat
i=false
repeat
t.poll(m,15000)
e,a,o=t.splice(r,s,d,l)
if e==nil then
return e,a,o
elseif e==0 then
u=true
break
elseif e then
i=true
end
until e==false
repeat
t.poll(f,15000)
e,a,o=t.splice(h,n,d,l)
if e==nil then
return e,a,o
elseif e then
i=true
end
until e==false
if c then
c(n)
end
if not i then
return false
end
until u
h:close()
s:close()
r:close()
n:close()
return true
end
local function p(s,h,r,n,l)
local c=f"os"
local d=65536
local u=t.splice_flags("move","more")
local a
local o,e,i=t.fork()
if not o then
return o,e,i
elseif o==0 then
r:close()
n:close()
repeat
a,e=t.splice(s,h,d,u)
until not a or a==0
h:close()
s:close()
c.exit(a or e)
else
h:close()
s:close()
repeat
a,e,i=t.splice(r,n,d,u)
if l then
l(n)
end
until not a or a==0
r:close()
n:close()
if not a then
t.kill(o,15)
t.wait(o)
return a,e,i
else
o,i,e=t.wait(o)
if i=="exited"then
if e==0 then
return true
else
return nil,e,t.strerror(e)
end
else
return nil,-17,"broken pump"
end
end
end
end
function request_to_file(s,a,o,n)
o=o or{}
n=n or{}
o.headers=o.headers or{}
local h=o.headers
local e,i,r
if a then
e,i,r=v(a)
if not e then
return e,i,r
end
local e=e:tell()
if e>0 then
h.Range=h.Range or("bytes="..e.."-")
end
end
local i,s,u,a=m.request_raw(s,o)
if not i then
if e then
e:close()
end
return i,s,u
elseif h.Range and i~=206 then
a:close()
if e then
e:close()
end
return nil,-4,i,s
elseif not h.Range and i~=200 then
a:close()
if e then
e:close()
end
return nil,-4,i,s
end
if n.on_header then
local t={n.on_header(e,i,s)}
if t[1]==false then
if e then
e:close()
end
a:close()
return w(t)
elseif t[2]then
e=e and t[2]
end
end
if not e then
return nil,-5,"no target given"
end
local l=s.headers["Transfer-Encoding"]=="chunked"
local d
e:writeall(u)
repeat
if not o.splice or not a:is_socket()or l then
break
end
local s,i,h=t.pipe()
if not s then
a:close()
e:close()
return s,i,h
end
local h=65536
local h=t.splice_flags("move","more")
local t,h,r=t.splice(a,i,512,h)
if t==nil then
break
end
local n=n.on_write
if o.splice=="asynchronous"then
t,h,r=y(a,i,s,e,n)
elseif o.splice=="synchronous"then
t,h,r=p(a,i,s,e,n)
else
break
end
if t==false then
break
end
return t,h,r
until true
local t=l and m.chunksource(a)or a:blocksource()
local o=e:sink()
if n.on_write then
t=c.source.chain(t,function(t)
n.on_write(e)
return t
end)
end
d,i,r=c.pump.all(t,o)
e:close()
a:close()
return d and true,i,r
end
