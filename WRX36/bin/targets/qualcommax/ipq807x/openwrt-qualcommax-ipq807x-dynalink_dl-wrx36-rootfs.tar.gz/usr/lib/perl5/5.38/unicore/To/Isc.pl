



$Unicode::UCD::SwashInfo{'ToIsc'}{'format'} = 'd'; # single decimal digit
$Unicode::UCD::SwashInfo{'ToIsc'}{'missing'} = ''; # code point maps to the empty string

return <<'END';
END
