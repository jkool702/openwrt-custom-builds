local e=require"luci.model.uci".cursor()
local a=require"luci.model.uci".cursor_state()
local o=require"table"
module"luci.jsonrpcbind.uci"
_M,_PACKAGE,_NAME=nil,nil,nil
function add(t,...)
e:load(t)
local a=e:add(t,...)
return e:save(t)and a
end
function apply(t)
return e:apply(t)
end
function changes(...)
return e:changes(...)
end
function commit(t)
return e:load(t)and e:commit(t)
end
function delete(t,...)
e:load(t)
return e:delete(t,...)and e:save(t)
end
function delete_all(t,...)
e:load(t)
return e:delete_all(t,...)and e:save(t)
end
function foreach(t,i)
e:load(t)
local a={}
return e:foreach(t,i,function(e)
o.insert(a,e)
end)and a
end
function get(t,...)
e:load(t)
return e:get(t,...)
end
function get_all(t,...)
e:load(t)
return e:get_all(t,...)
end
function get_state(e,...)
a:load(e)
return a:get(e,...)
end
function revert(t)
return e:load(t)and e:revert(t)
end
function section(t,...)
e:load(t)
return e:section(t,...)and e:save(t)
end
function set(t,...)
e:load(t)
return e:set(t,...)and e:save(t)
end
function tset(t,...)
e:load(t)
return e:tset(t,...)and e:save(t)
end
