#!/bin/sh

# ${INTERFACE} -- logical network interface (e.g. wan) which goes online or offline
# ${DEVICE} -- physical device (e.g. eth0) which goes online or offline
# ${GLOBAL} -- global state ONLINE or OFFLINE depending on wether device is online thru other interfaces
